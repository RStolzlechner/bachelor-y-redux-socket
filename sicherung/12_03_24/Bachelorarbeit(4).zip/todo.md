### 4 Implementierung und Tests
- [x] Latex Vorgehen beschreiben
- [x] traditional approach umsetzen (BRANCH: traditional)
- [x] Readme and Comments
- [x] Bug: 2. mal Selektion wird nicht aktualisiert.
- [x] CHAPTER: latex
    - [x] 4 und 4.1 Durchlesen und verbessern
    - [x] 4 und 4.1 KI verbessern lasse4n
- [] 4.2
    - [] schreiben
    - [] korrekturlesen
    - [] ki verbessern
- [] umbau auf y-redux-socket BRANCH: (y-redux-socket)
- [] CHAPTER: latex
- [] traditional um 1 CRUD feature erweitern (BRANCH: traditional-extended)
- [] y-redux-socket BRANCH um 1 CRUD feature erweitern (BRANCH: y-redux-socket-extended)
- [] CHAPTER: latex
- [] yredux-socket-extended Branch um Haeverbecke Algo erweitern
   - Testen und Verifizieren
        - Konsistenz
        - Was passiert wenn ein Client ofline geht
- [] CHAPTER: latex
- 
### Fazit
- [] Zusammenfassung
- [] Verbesserungspotential

### Algeimein
- [] Abstract
- [] Korrekturlesen (selbst) + verbessern
- [] Korrekturlesen (andere) + verbessern
- [] Repository Bachelorarbeit verlinken
- [] PPT
- [] Termin Abgabe und Kolloquium
- [] Probepräsentation
- [] Kolloquium
- [] Abgabe