### 2.11.23
- Mail an Dr. Ma wegen Anmeldung zur Abschlussarbeit (Start 15.4.24)

### 3.11.23
- Ergänzung 1.1 => Warum braucht man Yoshie im Baugewerbe
- Ergänzung 1.1 => clientzentrierte Konsistenzmodelle lt. Tannenbaum (monotones Lesen, Schreiben, Writes Follow Reads)
- Kapitel 1.2.3 YReduxSocket => Zu Kapitel 1.3 Ziele der Arbeit inkl. kurzer Absatz der die Ziele zusammenfasst
- Zeitplan neu erstellt

### 6.11.23
- Kapitel 2.3.1 Datenfluss und Kapitel 2.3.2 Actions

### 7.11.23
- Kapitel 2.3.1 Datenfluss erweitern (Selektoren, Actions, Reducer, Seiteneffekte)

### 6.12.23
- Text durch GPT4 gejagt und ersetzt

### TODO
- 2.3.1 Kernkonzepte formulieren

### TERMINE
- 18.04.24 15:00: Besprechung