### 4 Implementierung und Tests
- [] Sofware Architektur
- [] Client: Angular
- [] Server: ASP.Net
- [] Vergleich mit herkömmlichen Ansatz

### Fazit
- [] Zusammenfassung
- [] Verbesserungspotential

### Algeimein
- [] Abstract
- [] Korrekturlesen (selbst) + verbessern
- [] Korrekturlesen (andere) + verbessern
- [] PPT
- [] Termin Abgabe und Kolloquium
- [] Probepräsentation
- [] Kolloquium
- [] Abgabe